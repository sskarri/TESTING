package com.capgemini.file;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.autoconfigure.freemarker.FreeMarkerAutoConfiguration;
import org.springframework.stereotype.Component;
import org.springframework.ui.freemarker.FreeMarkerTemplateUtils;

import freemarker.template.Configuration;
import freemarker.template.Template;

@Component
public class VelocityConfig {

	   @Autowired
	   Configuration freemarkerConfiguration;
	   
	
   	Configuration cfg = new Configuration();

	 public String geFreeMarkerTemplateContent(Map<String, Object> model){
	        StringBuffer content = new StringBuffer();
	        try{
	        	cfg.setClassForTemplateLoading(this.getClass(), "/");
          	Template template = cfg.getTemplate("templates/velocity.ftl");
				
	         content.append(FreeMarkerTemplateUtils.processTemplateIntoString( 
	        		 template,model));
	         return content.toString();
	        }catch(Exception e){
	            System.out.println("Exception occured while processing fmtemplate:"+e.getMessage());
	        }
	          return "";
	    }
	
	/*   public String geVelocityTemplateContent(Map<String, Object> model){
	        StringBuffer content = new StringBuffer();
	        try{
	            content.append(VelocityEngineUtils.mergeTemplateIntoString(velocityEngine, "/vmtemplates/velocity_mailTemplate.vm", model));
	            return content.toString();
	        }catch(Exception e){
	            System.out.println("Exception occured while processing velocity template:"+e.getMessage());
	        }
	          return "";
	    }*/

}
