package com.capgemini.file;

import javax.servlet.http.HttpServletRequest;
import javax.sql.rowset.serial.SerialBlob; 

import org.springframework.batch.core.JobParametersInvalidException;
import org.springframework.batch.core.repository.JobExecutionAlreadyRunningException;
import org.springframework.batch.core.repository.JobInstanceAlreadyCompleteException;
import org.springframework.batch.core.repository.JobRestartException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.capgemini.batch.excel.ExcelFileToDatabaseJobLauncher;

@Component
@RestController
public class FileController {

	
	
	@Autowired
	FileRepository fileRepository;
	

	
	@Autowired
	ExcelFileReader excelFileReader;
	
	@Autowired
	ExcelFileToDatabaseJobLauncher excelFileToDatabaseJobLauncher;

	@RequestMapping("/hello")
	public String sayHello() {
		return "Hello !!";
	}
	@PostMapping("/uploadFile")
	public void uploadFile(@RequestParam(required = false) MultipartFile file) throws Exception {
		MyFileHolder myfile = new MyFileHolder();
		myfile.setFile(new SerialBlob(file.getBytes()));
	//	excelFileReader.readContents(file);
		FileMapper fmap = new FileMapper();
		fmap.setFile(file);
		//excelFileToDatabaseJobLauncher.launchXmlFileToDatabaseJob();
		FileCreators fc = new FileCreators();
		fc.writeFile(file);
		fileRepository.save(myfile);
	}
	
	@GetMapping("/process")
	public void processData() throws JobParametersInvalidException, JobExecutionAlreadyRunningException, JobRestartException, JobInstanceAlreadyCompleteException{
		
		excelFileToDatabaseJobLauncher.launchXmlFileToDatabaseJob();
	}
	
}
