package com.capgemini.batch;

import java.util.HashMap;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.item.ItemProcessor;

import com.capgemini.file.FileCreators;
import com.capgemini.file.VelocityConfig;
import com.capgemini.model.StudentDTO;

/**
 * This custom {@code ItemProcessor} simply writes the information of the
 * processed student to the log and returns the processed object.
 *
 * @author shysatya
 */
public class LoggingStudentProcessor implements ItemProcessor<StudentDTO, StudentDTO> {

	
	
	
	
    private static final Logger LOGGER = LoggerFactory.getLogger(LoggingStudentProcessor.class);
    
    @Override
    public StudentDTO process(StudentDTO item) throws Exception {
        LOGGER.info("Processing student information: {}", item);
        Map<String, Object> model = new HashMap<String, Object>();
        model.put("item", item);
    	VelocityConfig velocityConfig = new VelocityConfig();
        String html = velocityConfig.geFreeMarkerTemplateContent(model);
        FileCreators fileCreators = new FileCreators();
        fileCreators.writeFile(html, (int) Math.random()+System.currentTimeMillis());
        
        return item;
    }
}
