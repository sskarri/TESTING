package com.capgemini.pdf;

import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Image;
import com.itextpdf.text.PageSize;
import com.itextpdf.text.pdf.PdfContentByte;
import com.itextpdf.text.pdf.PdfWriter;
import com.itextpdf.tool.xml.XMLWorkerHelper;

import java.awt.image.BufferedImage;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.net.URL;

import javax.imageio.ImageIO;

import org.springframework.stereotype.Component;
 
@Component
public class ItextGenerator {


	 

	    /**
	     * Creates a PDF with the words "Hello World"
	     * @param file
	     * @throws IOException
	     * @throws DocumentException
	     */
	
	    public void createPdf(File hf,File pf) throws IOException, DocumentException {
	        // step 1
	        Document document = new Document();
	        // step 2
	        PdfWriter writer = PdfWriter.getInstance(document, new FileOutputStream(pf));
	        writer.setInitialLeading(12);
	        // step 3
	        document.open();
	        // step 4
	        XMLWorkerHelper.getInstance().parseXHtml(writer, document,
	                new FileInputStream(hf));
	        // step 5
	        PdfContentByte canvas = writer.getDirectContentUnder();
	        Image image = Image.getInstance("src/main/resources/images/logo.png");
	        image.scaleAbsolute(PageSize.A4.rotate());
	        image.setAbsolutePosition(0, 0);
	        canvas.addImage(image);
	        document.close();
	        hf.delete();
	    }
	
}
