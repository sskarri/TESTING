package com.capgemini.file;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;

import org.springframework.stereotype.Component;
import org.springframework.web.multipart.MultipartFile;

import com.capgemini.pdf.ItextGenerator;
import com.itextpdf.text.DocumentException;
@Component
public class FileCreators {

	

	public void writeFile(MultipartFile file) throws IOException{
		
	String path = "src/main/resources/data/";
		
		
		File f = new File(path+"System.xlsx");
		if (!f.exists()) {
			f.createNewFile();
		}
		FileOutputStream fos = new FileOutputStream(f);
		fos.write(file.getBytes());
		fos.flush();
		fos.close();
	}
	
	public void writeFile(String htmlText,long l) throws IOException, DocumentException{
		String htmlPath = "src/main/resources/htmlsrc/";
		String pdfPath = "src/main/resources/pdfs/";

		
		File hf = new File(htmlPath+l+"htmlsrc.html");
		File pf = new File(pdfPath+l+"pdfsrc.pdf");

		if (!hf.exists() && !pf.exists()) {
			
			hf.createNewFile();
			pf.createNewFile();
			
		}
		FileOutputStream fos = new FileOutputStream(hf);
		fos.write(htmlText.getBytes());
		fos.flush();
		fos.close();
		ItextGenerator pdfG = new ItextGenerator();
		pdfG.createPdf(hf, pf);
	}
}
